import asyncio, json, os, secrets, sqlite3, time
from pathlib import Path
from aiohttp import web, WSMsgType

BASE=Path(__file__).resolve().parent
DB=BASE/'fivedigit.sqlite3'
clients={}

def db():
 c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; c.execute('PRAGMA journal_mode=WAL'); return c

def init():
 with db() as c:
  c.executescript('''CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY, token TEXT NOT NULL);
  CREATE TABLE IF NOT EXISTS groups(id TEXT PRIMARY KEY, name TEXT NOT NULL, owner TEXT NOT NULL);
  CREATE TABLE IF NOT EXISTS members(group_id TEXT NOT NULL, user_id TEXT NOT NULL, PRIMARY KEY(group_id,user_id));
  CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY AUTOINCREMENT, sender TEXT NOT NULL, target TEXT NOT NULL, body TEXT NOT NULL, ts INTEGER NOT NULL);''')

def valid_id(x): return isinstance(x,str) and len(x)==5 and x.isascii() and x.isdigit()
def auth(req):
 uid=req.headers.get('X-User',''); token=req.headers.get('X-Token','')
 with db() as c: r=c.execute('SELECT token FROM users WHERE id=?',(uid,)).fetchone()
 if not r or not secrets.compare_digest(r['token'],token): raise web.HTTPUnauthorized(text='Sign in first')
 return uid
async def jsonbody(req):
 try: return await req.json()
 except Exception: raise web.HTTPBadRequest(text='Invalid JSON')
async def register(req):
 data=await jsonbody(req); uid=str(data.get('id',''))
 if not valid_id(uid): raise web.HTTPBadRequest(text='ID must be exactly 5 digits')
 token=secrets.token_urlsafe(32)
 try:
  with db() as c: c.execute('INSERT INTO users VALUES (?,?)',(uid,token))
 except sqlite3.IntegrityError: raise web.HTTPConflict(text='That ID is already taken')
 return web.json_response({'id':uid,'token':token})
async def login(req):
 data=await jsonbody(req); uid=str(data.get('id','')); token=str(data.get('token',''))
 with db() as c: row=c.execute('SELECT token FROM users WHERE id=?',(uid,)).fetchone()
 if not row or not secrets.compare_digest(row['token'],token): raise web.HTTPUnauthorized(text='Invalid saved identity')
 return web.json_response({'id':uid})
async def send(uid,payload):
 for ws in list(clients.get(uid,set())):
  if not ws.closed:
   try: await ws.send_json(payload)
   except Exception: pass
async def members(gid):
 with db() as c: return [r['user_id'] for r in c.execute('SELECT user_id FROM members WHERE group_id=?',(gid,))]
async def notify(target,payload):
 if target.startswith('g:'):
  for uid in await members(target[2:]): await send(uid,payload)
 else: await send(target,payload)
async def create_group(req):
 uid=auth(req); data=await jsonbody(req); name=str(data.get('name','')).strip()[:60]; ids=data.get('members',[])
 if not name or not isinstance(ids,list) or len(ids)>30 or any(not valid_id(x) for x in ids): raise web.HTTPBadRequest(text='Invalid group')
 ids=list(dict.fromkeys([uid]+ids))
 with db() as c:
  existing={r['id'] for r in c.execute('SELECT id FROM users WHERE id IN (%s)'%','.join('?'*len(ids)),ids)}
  if len(existing)!=len(ids): raise web.HTTPBadRequest(text='One or more IDs do not exist')
  gid=secrets.token_hex(5); c.execute('INSERT INTO groups VALUES (?,?,?)',(gid,name,uid)); c.executemany('INSERT INTO members VALUES (?,?)',[(gid,x) for x in ids])
 for x in ids: await send(x,{'type':'group_update'})
 return web.json_response({'id':gid,'name':name})
async def get_groups(req):
 uid=auth(req)
 with db() as c: rows=c.execute('SELECT g.id,g.name FROM groups g JOIN members m ON m.group_id=g.id WHERE m.user_id=?',(uid,)).fetchall()
 return web.json_response([dict(r) for r in rows])
async def history(req):
 uid=auth(req); target=req.query.get('target','')
 if target.startswith('g:'):
  if uid not in await members(target[2:]): raise web.HTTPForbidden()
 elif not valid_id(target): raise web.HTTPBadRequest(text='Invalid target')
 with db() as c:
  if target.startswith('g:'): rows=c.execute('SELECT * FROM messages WHERE target=? ORDER BY id DESC LIMIT 100',(target,)).fetchall()
  else: rows=c.execute('SELECT * FROM messages WHERE (sender=? AND target=?) OR (sender=? AND target=?) ORDER BY id DESC LIMIT 100',(uid,target,target,uid)).fetchall()
 return web.json_response([dict(r) for r in reversed(rows)])
async def ws_handler(req):
 uid=auth(req); ws=web.WebSocketResponse(heartbeat=25,max_msg_size=300000); await ws.prepare(req)
 clients.setdefault(uid,set()).add(ws)
 await ws.send_json({'type':'ready','id':uid})
 try:
  async for message in ws:
   if message.type!=WSMsgType.TEXT: continue
   try:
    d=json.loads(message.data); kind=d.get('type'); target=d.get('to','')
    if kind not in ('message','offer','answer','ice','hangup','ring'): continue
    if target.startswith('g:'):
     if kind!='message' or uid not in await members(target[2:]): continue
    elif not valid_id(target): continue
    if kind=='message':
     body=str(d.get('body','')).strip()[:4000]
     if not body: continue
     with db() as c:
      if not target.startswith('g:') and not c.execute('SELECT 1 FROM users WHERE id=?',(target,)).fetchone(): continue
      ts=int(time.time()); cur=c.execute('INSERT INTO messages(sender,target,body,ts) VALUES (?,?,?,?)',(uid,target,body,ts)); mid=cur.lastrowid
     payload={'type':'message','sender':uid,'target':target,'body':body,'ts':ts,'id':mid}
     await notify(target,payload)
     if not target.startswith('g:'): await send(uid,payload)
    else:
     # Relay signaling only; never persist SDP or ICE.
     payload={'type':kind,'from':uid,'video':bool(d.get('video',False)),'data':d.get('data')}
     if len(json.dumps(payload))>250000: continue
     await send(target,payload)
   except (ValueError,TypeError,KeyError): continue
 finally:
  clients.get(uid,set()).discard(ws)
 return ws

app=web.Application(client_max_size=1024*1024)
app.router.add_post('/api/register',register);app.router.add_post('/api/login',login)
app.router.add_post('/api/groups',create_group);app.router.add_get('/api/groups',get_groups)
app.router.add_get('/api/history',history);app.router.add_get('/ws',ws_handler)
app.router.add_get('/',lambda r:web.FileResponse(BASE/'static'/'index.html'))
app.router.add_static('/static',BASE/'static')
if __name__=='__main__':
 init(); host=os.environ.get('FIVEDIGIT_HOST','127.0.0.1');port=int(os.environ.get('PORT','8765'))
 print(f'FiveDigit server: http://{host}:{port}',flush=True);web.run_app(app,host=host,port=port)
