# FiveDigit

A self-hosted five-digit-ID messaging and WebRTC calling prototype.

## Start locally (Windows)
Install Python 3.10+, extract this folder, and double-click `RUN_WINDOWS.bat`.
Or run `python -m pip install -r requirements.txt` then `python server.py`.
Open http://127.0.0.1:8765 in your browser.

## Global deployment
Host the Python server on a public computer/VPS. Set `FIVEDIGIT_HOST=0.0.0.0` and `PORT=8765` (or configure the platform's PORT). Put an HTTPS reverse proxy in front (Caddy or Nginx) with WebSocket support. All participants open **the same HTTPS URL**. Never expose this HTTP-only local development setup directly to the public internet without HTTPS and security hardening.

## What works
- Claim a unique five-digit ID; private login token saved in browser localStorage.
- Send persistent direct messages and create group chats (up to 30 invited members).
- One-to-one WebRTC audio/video calls using browser microphone/camera.
- Notifications for incoming calls/messages **while the page is open** (desktop notifications when tab is hidden and permission granted).

## Limitations / production requirements
- Calls may fail behind restrictive NATs because only a public STUN server is configured. Add a TURN relay for dependable global calling; it has bandwidth costs.
- This version **does not** deliver push notifications or ring when the page/browser is fully closed. That requires HTTPS, a service worker, Web Push subscription storage, VAPID credentials, and a push delivery service (browsers use their push infrastructure). Some mobile platforms restrict background delivery.
- Only the browser that originally registered an ID retains its token. Clearing storage loses access. No recovery mechanism yet.
- Five-digit IDs offer only 100,000 possibilities. Add abuse prevention, rate limiting, account recovery, block/report, and stronger authentication before public deployment.
- Group chats are supported; **group video/audio calls are not**.
- Messages are stored in SQLite on the server and are not end-to-end encrypted.
- Call notifications are best effort; calls need both users connected to the page in this version.
- No guarantee that every network or browser supports the camera/microphone or peer connection.
