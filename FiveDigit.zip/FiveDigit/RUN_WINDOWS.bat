@echo off
cd /d "%~dp0"
py -m pip install -r requirements.txt
if errorlevel 1 pause & exit /b 1
start "" http://127.0.0.1:8765
py server.py
pause
